console.log("Register page");
let saloon={
    name:"The Fashion Pet",
    address:{
        street:"University",
        number:"758-K",
        zip:"22569",
        city:"San Diego",
    },
    hours:{
        open:"9:00 am",
        close:"20:00 pm"
    },
    pets:[]
    
}
//create a constructor

//create a pet constructor
let x=0;
function Pet(name,age,gender,breed,services,ownerName,contactPhone,comments){
        this.name=name;
        this.age=age;
        this.gender=gender;
        this.breed=breed;
        this.services=services;
        this.owner=ownerName;
        this.phone=contactPhone;
        this.comments=comments;
        this.id=x++;
}
let scooby= new Pet("Scooby",50,"Male","Dane","Grooming","Shaggy","666-6666");
let fluffy= new Pet("Fluffy",10,"Male","boxer","Grooming","Fred","666-6666");
let cherry= new Pet("Cherry",9,"Male","terrier","Grooming","Wilma","666-6666");
let snoopy= new Pet("Snoopy",12,"Male","bulldog","Grooming","Daffny","666-6666");


saloon.pets.push(scooby,fluffy,cherry,snoopy);
console.log(saloon.pets);



displayCards(scooby);
displayCards(fluffy);
displayCards(cherry);
displayCards(snoopy);

//get the values from the input  
let txtName =document.getElementById("petName");
let txtAge =document.getElementById("petAge");
let txtGender =document.getElementById("petGender");
let txtBreed =document.getElementById("petBreed");
let txtService =document.getElementById("petService");
let txtOwner =document.getElementById("ownerName");
let txtPhone =document.getElementById("ownerPhone");
let txtComments =document.getElementById("ownerComments");

function register(){
    console.log(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value, txtComments.value)
    
    let newPet=new Pet(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value, txtComments.value)
   saloon.pets.push(newPet)
   console.log(saloon.pets)
   displayCards(newPet);
   clear();
//create a constructor usgin the values from the input
//push it into the array
//display the pet on the console
//clear the inputs
}

function clear(){
    txtName.value="";
    txtAge.value="";
    txtGender.value="";
    txtBreed.value="";
    txtService.value="";
    txtOwner.value="";
    txtPhone.value="";
    txtComments.value="";
}
function simpleDisplay(){
    console.log(saloon.pets[0].name);
    //display the name of the pets(4)
}
//simpleDisplay();

function deletePet(petId){
    console.log("Delete pet" +petId);
    
    for(let i=0;i<saloon.pets.length;i++){
        let pet=saloon.pets[i];
        if(petId===pet.id){
            indexDelete=i;
        }
    }
    document.getElementById(petId).remove();
//search the pet
//delete pet from html
saloon.pets.splice(indexDelete,1);
//delete pet from array
}

function searchPet(){
    let searchString=document.getElementById("txtSearch").value;
    for(let i=0; i<saloon.pets.length;i++){
        if(searchString==saloon.pets[i].name){
            document.getElementById(saloon.pets[i].id).classList.add("highlight");
        }
    }
    console.log(searchString);
    
}



